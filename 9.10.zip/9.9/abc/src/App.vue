<template>
	<div id="app">
		<body1></body1>
	</div>
</template>

<script>
	import body1 from './assets/body/body.vue'
	export default {
		name: 'app',
		data() {
			return {
				msg: 'Welcome to Your Vue.js App'
			}
		},
		components:{
			"body1":body1
		}
	}
</script>

<style lang="css">
	.demo-infinite-container {
		width: 100%;
		height: 100%;
		overflow: auto;
		-webkit-overflow-scrolling: touch;
		border: 1px solid #d9d9d9;
	}
</style>