import Vue from 'vue'
import App from './App.vue'
import MuseUI from 'muse-ui'
import 'muse-ui/dist/muse-ui.css'
Vue.use(MuseUI)

import vr from 'vue-router'
Vue.use(vr)


import tianqi from './assets/body/tianqi.vue'
import tiyu from './assets/body/tiyu.vue'
import mingjia from './assets/body/mingjia.vue'
import yule from './assets/body/yule.vue'
import junshi from './assets/body/junshi.vue'
var router1 = new vr({
	routes:[
		{path:"/tianqi",component:tianqi},
		{path:"/tiyu",component:tiyu},
		{path:"/mingjia",component:mingjia},
		{path:"/yule",component:yule},
		{path:"/junshi",component:junshi}
	]
})

new Vue({
  el: '#app',
  router:router1,
  render: h => h(App)
})
