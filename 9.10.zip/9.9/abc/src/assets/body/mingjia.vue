<template>
  <div id="app">
    <table>
    	<tr v-for="item in items">
    		<td>{{item.author_name}}</td>
    		<td>{{item.category}}</td>
    		<td><img v-bind:src="item.thumbnail_pic_s"/></td>
    		<td><img v-bind::src="item.thumbnail_pic_s02"/></td>
    		<td><img v-bind::src="item.thumbnail_pic_s03"/></td>
    		<td>{{item.title}}</td>
    	</tr>
    </table>
  </div>
</template>

<script>
	import axios from 'axios'
export default {
  name: 'app',
  data () {
    return {
      items:[]
    }
  },
  created:function(){
  	var url="http://guoxiao158.top/toutiao.php?type=mingjia"
  	
  	axios.get(url).then((res)=>{
  		console.log(res.data.result.data)
		this.items = res.data.result.data;
  	})
  }
}
</script>

<style scoped="scoped">

</style>
