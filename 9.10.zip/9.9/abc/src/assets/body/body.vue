<template>
	<div>
		<div id="body">
			<router-link to="/tianqi">天气</router-link>
			<router-link to="/tiyu">体育</router-link>
			<router-link to="/mingjia">名家</router-link>
			<router-link to="/yule">娱乐</router-link>
			<router-link to="/junshi">军事</router-link>
		</div>
		<div>
			<router-view></router-view>
		</div>
	</div>
</template>

<script>
</script>

<style>

</style>