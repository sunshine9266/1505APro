<template>
  <div id="app">
    <table>
    	<tr v-for="item in items">
    		<td>{{item.date}}</td>
    		<td>{{item.high}}</td>
    		<td>{{item.fengli}}</td>
    		<td>{{item.low}}</td>
    		<td>{{item.fengxiang}}</td>
    		<td>{{item.type}}</td>
    	</tr>
    </table>
  </div>
</template>

<script>
	import axios from 'axios'
export default {
  name: 'app',
  data () {
    return {
      items:[]
    }
  },
  created:function(){
  	var url="http://wthrcdn.etouch.cn/weather_mini?city=%E5%8C%97%E4%BA%AC"
  	
  	axios.get(url).then((res)=>{
  		console.log(res.data.data.forecast)
  		this.items = res.data.data.forecast
  	})
  }
}
</script>

<style scoped="scoped">
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}

h1, h2 {
  font-weight: normal;
}

ul {
  list-style-type: none;
  padding: 0;
}

li {
  display: inline-block;
  margin: 0 10px;
}

a {
  color: #42b983;
}
</style>
