<template>
	<div>
		这是视频
	</div>
</template>

<script>
</script>

<style>
</style>