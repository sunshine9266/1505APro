<template>
	<div>
	<table class="table" v-for="item in items">

		<tr>
			<td>
				<h3>{{item.title}}</h3><img :src="item.thumbnail_pic_s"></td>
			<td>{{item.date}}{{item.category}}</td>
			<td></td>
			<td></td>
			<td></td>

		</tr>
	</table>	
	</div>
	
</template>

<script>
	import axios from 'axios'
	export default {
		name: 'app',
		data() {
			return {
				items: []
			}
		},
		created: function() {
			var url = "http://guoxiao158.top/toutiao.php?type=tiyu"

			axios.get(url).then((res) => {
				console.log(res.data.result.data)
				this.items = res.data.result.data
			})
		}
	}
</script>

<style>
	.head {
		width: 100%;
		background-color: gainsboro;
	}
	
	.a1 {
		margin-left: 10%;
	}
</style>