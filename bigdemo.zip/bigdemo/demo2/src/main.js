import Vue from 'vue'
import App from './App.vue'

import VueRouter from 'vue-router'
Vue.use(VueRouter);

import tiyu from './tiyu.vue' 
import tuijian from './tuijian.vue' 
import shipin from './shipin.vue' 
import mingjia from './mingjia.vue' 
import yule from './yule.vue' 
import keji from './keji.vue' 

import VueAwesomeSwiper from 'vue-awesome-swiper'
Vue.use(VueAwesomeSwiper);

var vueRouter = new VueRouter ({
	routes:[
	{path: '/',redirect: 'tiyu'},
	{path:'/tiyu',component:tiyu},
	{path:'/tuijian',component:tuijian},
	{path:'/shipin',component:shipin},
	{path:'/mingjia',component:mingjia},
	{path:'/yule',component:yule},
	{path:'/keji',component:keji},
	]
})

new Vue({
  el: '#app',
  router:vueRouter,
  render: h => h(App)
})
